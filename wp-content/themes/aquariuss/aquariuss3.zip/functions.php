<?php
require get_stylesheet_directory() . '/inc/init.php';
require get_stylesheet_directory() . '/inc/candy.php';
require get_stylesheet_directory() . '/inc/general.php';
require get_stylesheet_directory() . '/inc/languages.php';