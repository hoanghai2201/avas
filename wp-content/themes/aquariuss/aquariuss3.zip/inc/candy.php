<?php
function theme_setup() {
    add_theme_support('title-tag');
}
add_action('after_setup_theme', 'theme_setup');

// https://developer.wordpress.org/resource/dashicons/#leftright
function create_candy_post_type() {
    $labels = array(
        'name'                  => 'Candy',
        'singular_name'         => 'Candy',
        'menu_name'             => 'Candy',
        'name_admin_bar'        => 'Candy',
        'add_new'               => 'Add New',
        'add_new_item'          => 'Add New Candy',
        'new_item'              => 'New Candy',
        'edit_item'             => 'Edit Candy',
        'view_item'             => 'View Candy',
        'all_items'             => 'All Candy',
        'search_items'          => 'Search Candy',
        'not_found'             => 'No Candy found.',
    );
  
    $args = array(
        'labels'                => $labels,
        'public'                => true,
        'publicly_queryable'    => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => array('slug' => 'candy'),
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-store',  // Set icon cho CPT Candy
        'supports'              => array('title', 'editor', 'thumbnail', 'excerpt'),
        // 'taxonomies'            => array('category'), // Thêm category vào CPT
    );
    register_post_type('candy', $args);
}
add_action('init', 'create_candy_post_type');

function create_candy_taxonomy() {
    $labels = array(
        'name'              => 'Candy Categories',
        'singular_name'     => 'Candy Category',
        'search_items'      => 'Search Candy Categories',
        'all_items'         => 'All Candy Categories',
        'parent_item'       => 'Parent Category',
        'parent_item_colon' => 'Parent Category:',
        'edit_item'         => 'Edit Candy Category',
        'update_item'       => 'Update Candy Category',
        'add_new_item'      => 'Add New Candy Category',
        'new_item_name'     => 'New Candy Category Name',
        'menu_name'         => 'Candy Categories',
    );
    
    $args = array(
        'hierarchical'      => true, // Phân cấp như category
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'candy-category'),
    );
  
    register_taxonomy('candy_category', array('candy'), $args);
}
add_action('init', 'create_candy_taxonomy', 0);