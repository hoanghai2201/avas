<?php
/**
 * The blog template file.
 *
 * @package          Trang Tien Plaza\Templates
 * @trangtienplaza-version 1.0.0
 */

get_header();
global $domain;

if(wp_is_mobile()){
    $background = get_field('background_image_mobile');
} else {
    $background = get_field('background_image');
}
?>
<div id="content" role="main" class="content-area">
    <?php if(!empty($background)): ?>
    <section class="section" id="section_223760777">
        <div class="bg section-bg fill bg-fill bg-loaded">
        </div>
        <div class="section-content relative">
            <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1755769548">
                <div class="img-inner dark">
                    <img fetchpriority="high" decoding="async" width="1920" height="824" src="<?php echo esc_url($background['url']); ?>" class="attachment-original size-original" alt="<?php echo esc_attr($background['alt']); ?>">
                </div>
                <style>
                    #image_1755769548 {
                        width: 100%;
                    }
                </style>
            </div>
        </div>
        <style>
            #section_223760777 {
                padding-top: 0px;
                padding-bottom: 0px;
            }
            #section_223760777 .ux-shape-divider--top svg {
                height: 150px;
                --divider-top-width: 100%;
            }
            #section_223760777 .ux-shape-divider--bottom svg {
                height: 150px;
                --divider-width: 100%;
            }
        </style>
    </section>
    <?php endif; ?>

    <section class="section section-has-bg pb-5r" id="section_176697456" style="padding-top:0;">
        <div class="bg section-bg fill bg-fill bg-loaded"> </div>
        <div class="section-content relative">
            <div class="row" id="row-1727113603">
                <div class="col small-12 large-12 box-top-detail">
                    <div class="row">
                        <div class="col small-12 medium-6 box-title">
                            <h3 class="text-left title-detal-brand"><?php the_title(); ?></h3>
                        </div>
                        <div class="col small-12 medium-6 pbm-0">
                            <div class="box-desc-brand">
                                <?php echo nl2br(get_field('description')); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if(!wp_is_mobile()): ?>
                <div id="col-115151647" class="col small-12 large-12">
                    <div class="slider-wrapper relative hide-for-medium" id="slider-1828561487">
                        <div class="slider slider-nav-circle slider-nav-normal slider-nav-light slider-style-normal" data-flickity-options='{"cellAlign": "center","imagesLoaded": true,"lazyLoad": 1,"freeScroll": false,"wrapAround": true,"autoPlay": 6000,"pauseAutoPlayOnHover" : true,"prevNextButtons": true,"contain" : true,"adaptiveHeight" : true,"dragThreshold" : 10,"percentPosition": true,"pageDots": false,"rightToLeft": false,"draggable": true,"selectedAttraction": 0.1,"parallax" : 0,"friction": 0.6}'>
                            <?php 
                            $slides = get_field('gallery');
                            if($slides): ?>
                                <?php $i = 0; ?>
                                <?php foreach($slides as $image): ?>
                                    <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_s1<?php echo $i; ?>">
                                        <div class="img-inner dark">
                                            <img fetchpriority="high" decoding="async" width="1920" height="901" src="<?php echo esc_url($image['sizes']['large']); ?>" class="attachment-large size-large" alt="<?php echo esc_attr($image['alt']); ?>" />
                                        </div>
                                        <style>
                                            #image_s1<?php echo $i; ?> {
                                                width: 100%;
                                            }
                                        </style>
                                    </div>
                                <?php $i++; ?>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <div class="loading-spin dark large centered"></div>
                    </div>
                </div>
                <?php  endif; ?>
            </div>
            <?php if(wp_is_mobile()): ?>
            <div class="row slide-arrivals slide-mb large-columns-4 medium-columns-1 small-columns-1 row-small slider row-slider slider-nav-simple slider-nav-push" data-aos="fade-up" data-flickity-options='{"imagesLoaded": true, "groupCells": 1, "dragThreshold" : 5, "cellAlign": "center","wrapAround": true,"prevNextButtons": true,"percentPosition": true,"pageDots": false, "rightToLeft": false, "autoPlay" : false}'>
                <?php 
                $slides = get_field('gallery');
                if($slides): ?>
                    <?php $i = 0; ?>
                    <?php foreach($slides as $image): ?>
                        <div class="col post-item">
                            <div class="col-inner">
                                <div class="box box-normal box-text-bottom box-blog-post has-hover">
                                    <div class="box-image">
                                        <div class="image-zoom image-cover" style="padding-top:75%;"> 
                                            <img decoding="async" width="320" height="401" src="<?php echo esc_url($image['sizes']['large']); ?>" class="attachment-medium size-medium wp-post-image" alt="<?php echo esc_attr($image['alt']); ?>" /> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <?php  endif; ?>
        </div>
        <style>
            #section_176697456 .ux-shape-divider--top svg {
                height: 150px;
                --divider-top-width: 100%;
            }

            #section_176697456 .ux-shape-divider--bottom svg {
                height: 150px;
                --divider-width: 100%;
            }
        </style>
    </section>
    
    <section class="section py-5 ptm-25" id="section_477863630">
        <div class="bg section-bg fill bg-fill  bg-loaded">
        </div>
        <div class="section-content relative">
            <div id="text-1869774287" class="text">
            </div>
            
            <?php
                if(have_rows('list_info')):
                    $i = 0;
                    while(have_rows('list_info')) : the_row();
                        $i++;
                        $title = get_sub_field('title');
                        $image_large = get_sub_field('large_image');
                        $image_small = get_sub_field('small_image');
                        $description = get_sub_field('description');
                ?>
                    <?php if(wp_is_mobile()): ?>
                        <div class="list-pl">
                            <div class="item-pl">
                                <div class="top-pl">
                                    <div class="left-pl">
                                        <img decoding="async" src="<?php echo esc_url($image_large['url']); ?>" alt="<?php echo esc_attr($image_large['alt']); ?>" srcset="<?php echo esc_url($image_large['url']); ?>, <?php echo esc_url($image_large['url']); ?>" sizes="(max-width: 608px) 100vw, 608px" data-aos="fade-up" data-aos-delay="200" />
                                    </div>
                                    <div class="right-pl">
                                       <h2 data-aos="fade-up" data-aos-delay="200">0<?php echo $i; ?></h2>
                                        <img decoding="async" width="480" height="361" src="<?php echo esc_url($image_small['url']); ?>" alt="<?php echo esc_attr($image_small['alt']); ?>" data-aos="fade-up" data-aos-delay="400" /> 
                                    </div>
                                </div>
                                <div class="bottom-pl">
                                    <h3 class="w80 text-left" data-aos="fade-up" data-aos-delay="600"><?php echo $title; ?></h3>
                                    <p class="w80 text-left" data-aos="fade-up" data-aos-delay="800"><?php echo $description; ?></p>
                                </div>
                            </div>
                        </div>
                    <?php else:  ?>
                        <?php if($i%2 == 0): ?>
                            <div class="row row-large align-equal box-leasing box-leasing-bt box-leasing-left" id="row-326244481">
                                <div id="col-1422373480" class="col medium-6 small-12 large-6 box-leasing-sm item-service">
                                    <div class="col-inner">
                                        <h2 data-aos="fade-up" data-aos-delay="200">0<?php echo $i; ?></h2>
                                        <h3 class="w80" data-aos="fade-up" data-aos-delay="400"><?php echo $title; ?></h3>
                                        <p class="w80" data-aos="fade-up" data-aos-delay="600"><?php echo $description; ?></p>
                                        <div class="img-leasing img has-hover x md-x lg-x y md-y lg-y w80" id="image_776904495">
                                            <div class="img-inner image-zoom dark" data-aos="fade-up" data-aos-delay="800">
                                                <img decoding="async" width="480" height="361" src="<?php echo esc_url($image_small['url']); ?>" class="attachment-large size-large" alt="<?php echo esc_attr($image_small['alt']); ?>" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="col-1762630647" class="col medium-6 small-12 large-6">
                                    <div class="col-inner">
                                        <div class="img has-hover x md-x lg-x y md-y lg-y" style="width: 100%;">
                                            <div class="img-inner image-zoom image-cover dark" data-aos="fade-up" data-aos-delay="200" style="padding-top:160%;">
                                                <img decoding="async" width="608" height="761" src="<?php echo esc_url($image_large['url']); ?>" alt="<?php echo esc_attr($image_large['alt']); ?>" srcset="<?php echo esc_url($image_large['url']); ?>, <?php echo esc_url($image_large['url']); ?>" sizes="(max-width: 608px) 100vw, 608px" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="row row-large align-equal box-leasing item-service" id="row-1128706920">
                                <div id="col-1088160197" class="col medium-6 small-12 large-6">
                                    <div class="col-inner">
                                        <div class="img has-hover x md-x lg-x y md-y lg-y" style="width: 100%;">
                                            <div class="img-inner image-zoom image-cover dark" style="padding-top:160%;">
                                                <img decoding="async" width="608" height="761" src="<?php echo esc_url($image_large['url']); ?>" alt="<?php echo esc_attr($image_large['alt']); ?>" srcset="<?php echo esc_url($image_large['url']); ?>, <?php echo esc_url($image_large['url']); ?>" sizes="(max-width: 608px) 100vw, 608px" data-aos="fade-up" data-aos-delay="200" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="col-1858445681" class="col medium-6 small-12 large-6 box-leasing-sm">
                                    <div class="col-inner">
                                        <h2 data-aos="fade-up" data-aos-delay="200">0<?php echo $i; ?></h2>
                                        <h3 class="w80" data-aos="fade-up" data-aos-delay="400"><?php echo $title; ?></h3>
                                        <p class="w80" data-aos="fade-up" data-aos-delay="600"><?php echo $description; ?></p>
                                        <div class="img-leasing img has-hover x md-x lg-x y md-y lg-y w80" id="image_595176311">
                                            <div class="img-inner image-zoom dark" data-aos="fade-up" data-aos-delay="800">
                                                <img decoding="async" width="480" height="361" src="<?php echo esc_url($image_small['url']); ?>" alt="<?php echo esc_attr($image_small['alt']); ?>" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php
                    endwhile;
                endif;
            ?>
        </div>
        <style>
            #section_477863630 {
                padding-top: 30px;
                padding-bottom: 30px;
            }
            #section_477863630 .ux-shape-divider--top svg {
                height: 150px;
                --divider-top-width: 100%;
            }
            #section_477863630 .ux-shape-divider--bottom svg {
                height: 150px;
                --divider-width: 100%;
            }
        </style>
    </section>

    <section class="section py-3 bt-1" id="section_1682728161" data-aos="fade-up">
        <div class="bg section-bg fill bg-fill bg-loaded">
        </div>
        <div class="section-content relative">
            <div id="text-1869774287" class="text">
                <h3 class="title-services py-2" data-aos="fade-up"><?php echo get_field('footer_title'); ?></h3>
                <style>
                    #text-1869774287 {
                        text-align: center;
                    }
                </style>
            </div>
            <div class="row align-equal" id="row-1945709524">
                <div id="col-110823118" class="col medium-4 small-12 large-4 box-info-brand" data-aos="fade-left" data-aos-delay="200">
                    <div class="col-inner">
                        <div id="text-2325213749" class="text box-sm-contact pd-0">
                            <p class="text-top-brand"><?php echo get_field('floor_info'); ?></p>
                            <h4 class="f24 mb-24"><?php echo get_field('location'); ?></h4>
                            <p class="text-bottom"><?php echo get_field('address'); ?></p>
                        </div>
                    </div>
                </div>
                <div id="col-1852955908" class="col medium-4 small-12 large-4 box-info-brand" data-aos="fade-left" data-aos-delay="400">
                    <div class="col-inner">
                        <div id="text-2651367777" class="text box-sm-contact pd-0">
                            <p class="text-small"><?php echo get_field('call_us'); ?></p>
                            <h4 class="f24 mb-24"><a href="tel:<?php echo str_replace(['.','+','(',')',' '],'', get_field('phone')); ?>"><?php echo get_field('phone'); ?></a></h4>
                            <p class="text-small"><?php echo pll__('Send us a message'); ?></p>
                            <p class="text-bottom"><a href="mailto:<?php echo get_field('email'); ?>"><?php echo get_field('email'); ?></a></p>
                        </div>
                    </div>
                </div>
                <div id="col-446381598" class="col medium-4 small-12 large-4 box-info-brand" data-aos="fade-left" data-aos-delay="600">
                    <div class="col-inner">
                        <div id="text-4000940263" class="text box-sm-contact pd-0">
                            <p class="text-small"><?php echo pll__('Opening hours'); ?></p>
                            <div class="open-hours">
                                <?php echo get_field('opening_hours'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row pyt-3">
                <div class="col medium-12 small-12 large-12 box-img-brand">
                    <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1755769548">
                        <div class="img-inner dark">
                            <img fetchpriority="high" decoding="async" width="1920" height="824" src="<?php echo esc_url(get_field('brand_image')['url']); ?>" class="attachment-original size-original" alt="<?php echo esc_attr(get_field('brand_image')['alt']); ?>">
                        </div>
                        <style>
                            #image_1755769548 {
                                width: 100%;
                            }
                        </style>
                    </div>
                </div>
            </div>
        </div>
        <style>
            #section_1682728161 {
                padding-top: 30px;
                padding-bottom: 30px;
            }
            #section_1682728161 .ux-shape-divider--top svg {
                height: 150px;
                --divider-top-width: 100%;
            }
            #section_1682728161 .ux-shape-divider--bottom svg {
                height: 150px;
                --divider-width: 100%;
            }
        </style>
    </section>
</div>

<?php get_footer(); ?>