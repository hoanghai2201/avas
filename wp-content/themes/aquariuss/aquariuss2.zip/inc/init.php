<?php
global $domain;
// $current_language = pll_current_language();
// $site_url = home_url();
$domain = get_option('siteurl'); //str_replace('/' . $current_language, '', $site_url);

function get_latest_posts_by_category($category_id, $num_post = 5, $offset = 0){
	$current_language = pll_current_language();
	$translated_category_id = pll_get_term($category_id);
    $args = array(
        'cat'            => $translated_category_id,
        'posts_per_page' => $num_post,
        'offset'         => $offset,
        'lang'           => $current_language,
        'orderby'        => 'date', 
        'order'          => 'DESC',
    );
    $query = new WP_Query($args);
    return $query;
}

function get_category_title_by_id($category_id) {
	$translated_category_id = pll_get_term($category_id);
    $category = get_category($translated_category_id);
    if ($category) {
        return pll__($category->name);
    }
    return '';
}

function custom_posts_per_page_by_category($query) {
    if ($query->is_category() && $query->is_main_query()) {
        $current_category = get_queried_object();
        if ($current_category) {
            $category_id = pll_get_term($current_category->term_id, pll_current_language());
            if (wp_is_mobile()) {
                $query->set('posts_per_page', 9);
            } else {
                $query->set('posts_per_page', 9);
            }
        }
    }
    if($query->is_tax('luxury_category') && $query->is_main_query()){
        $current_language = pll_current_language();
        $current_category = get_queried_object();
        if ($current_category) {
            $category_id = pll_get_term($current_category->term_id, pll_current_language());
            if(in_array($category_id, [137, 139])) { // Timeless Treasure
                if (wp_is_mobile()) {
                    $query->set('posts_per_page', 6);
                } else {
                    $query->set('posts_per_page', 9);
                }
            } else {
                if (wp_is_mobile()) {
                    $query->set('posts_per_page', 6);
                } else {
                    $query->set('posts_per_page', 9);
                }
            }
        }
    }
}
add_action('pre_get_posts', 'custom_posts_per_page_by_category');

function use_custom_single_template($template) {
    if(is_single() && in_category([236,244,318,320])) { // ID của chuyên mục  // 236,244: local
        $custom_template = locate_template('single-talents.php');
        if ($custom_template) {
            return $custom_template;
        }
    }
    return $template;
}
add_filter('single_template', 'use_custom_single_template');

function get_acf_checkbox_values($field_name) {
    $values = array();
    $posts = get_posts(array(
        'post_type' => 'post', // Loại bài viết
        'posts_per_page' => -1, // Lấy tất cả bài viết
        'fields' => 'ids', // Lấy ID để tối ưu hóa
    ));

    foreach ($posts as $post_id) {
        $field_values = get_post_meta($post_id, $field_name, true);
        if (is_array($field_values)) {
            foreach ($field_values as $value) {
                $values[] = $value;
            }
        }
    }

    return array_unique($values); // Loại bỏ giá trị trùng lặp
}

function get_all_brand_taxonomies() {
    // Lấy tất cả Brand Categories
    $brand_categories = get_terms([
        'taxonomy'   => 'brand_category',
        'hide_empty' => false, // Hiển thị cả các term không có bài viết
    ]);

    if (!empty($brand_categories) && !is_wp_error($brand_categories)) {
        $categories = array_map(function($term) {
            return [
                'id' => $term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'link' => get_term_link($term), // Polylang xử lý link tự động
            ];
        }, $brand_categories);
    } else {
        $categories = [];
    }

    // Lấy tất cả Brand Floors
    $brand_floors = get_terms([
        'taxonomy'   => 'brand_floor',
        'hide_empty' => false, // Hiển thị cả các term không có bài viết
    ]);

    if (!empty($brand_floors) && !is_wp_error($brand_floors)) {
        $floors = array_map(function($term) {
            return [
                'id' => $term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'link' => get_term_link($term), // Polylang xử lý link tự động
            ];
        }, $brand_floors);
    } else {
        $floors = [];
    }

    return [
        'categories' => $categories,
        'floors'     => $floors,
    ];
}

function search_only_in_titles($search, $wp_query) {
    global $wpdb;

    if ($wp_query->is_search() && !is_admin()) {
        $search_query = $wp_query->get('s');
        if (!empty($search_query)) {
            $search = $wpdb->prepare(" AND {$wpdb->posts}.post_title LIKE '%%%s%%' ", $search_query);
        }
    }

    return $search;
}
add_filter('posts_search', 'search_only_in_titles', 10, 2);

function search_in_luxury_and_brand($query) {
    if ($query->is_search && $query->is_main_query() && !is_admin()) {
        $query->set('post_type', array('luxury', 'brand', 'post'));
    }
}
add_action('pre_get_posts', 'search_in_luxury_and_brand');

// function remove_default_favicons() {
//     remove_action('wp_head', 'wp_site_icon', 99);
// }
// add_action('after_setup_theme', 'remove_default_favicons');

function my_custom_body_classes($classes) {
    // Thêm class tùy chỉnh 'my-custom-class'
    $classes[] = 'lightbox nav-dropdown-has-arrow nav-dropdown-has-shadow nav-dropdown-has-border';

    // if (is_home()) {
    //     $classes[] = 'home-page';
    // }

    return $classes;
}
add_filter('body_class', 'my_custom_body_classes');


function custom_polylang_langswitcher() {
  $output = '';
  if (function_exists('pll_the_languages')) {
    $args = [
      'show_flags' => 1,
      'show_names' => 1,
      'hide_if_empty' => 0,
      'hide_current' => 0,
      'echo' => 0,
    ];
    $output = '<ul class="polylang_langswitcher">'.pll_the_languages($args).'</ul>';
  }
  return $output;
}
add_shortcode('polylang_langswitcher', 'custom_polylang_langswitcher');

function custom_admin_css_for_specific_page() {
    $screen = get_current_screen();
    
    // Kiểm tra nếu đang ở trang chỉnh sửa post/page có ID 42
    if (isset($_GET['post']) && in_array($_GET['post'], [41, 792]) == 42 && $screen->base == 'post') {
        echo '<style>
        		.postarea {
        			display: none;
        		}
        	  </style>';
    }
}
add_action( 'admin_enqueue_scripts', 'custom_admin_css_for_specific_page' );

if (function_exists('add_theme_support')) {
    add_theme_support('post-thumbnails');
}

function register_my_menu() {
    register_nav_menus(
        array(
            'main-menu' => __('Menu Main'),
            'footer-menu' => __('Menu Footer')
        )
    );
}
add_action('init', 'register_my_menu');

if (function_exists('max_mega_menu_is_enabled')) {
    // Gỡ bỏ mega menu
}

add_action( 'admin_init', 'disable_autosave' );
function disable_autosave() {
    wp_deregister_script( 'autosave' );
}

function set_dflip_slug_as_id($data, $postarr) {
    if ($data['post_type'] === 'dflip' && $data['post_status'] !== 'auto-draft') {
        // Nếu bài viết mới chưa có ID, đặt slug tạm thời
        if (empty($postarr['ID'])) {
            $data['post_name'] = sanitize_title(uniqid('dflip-')); // Tạo slug tạm thời
        } else {
            $data['post_name'] = (string) $postarr['ID']; // Đặt slug bằng ID
        }
    }
    return $data;
}
add_filter('wp_insert_post_data', 'set_dflip_slug_as_id', 10, 2);

// Thêm trường ảnh tùy chỉnh vào mục menu
function add_custom_image_field_to_menu($item_id, $item, $depth, $args) {
    // Lấy giá trị của ảnh từ meta
    $menu_item_image = get_post_meta($item_id, '_menu_item_image', true);

    ?>
    <p class="description description-wide">
        <label for="edit-menu-item-image-<?php echo $item_id; ?>">
            <?php _e( 'Menu Image (URL)', 'your-theme-text-domain' ); ?><br />
            <input type="text" id="edit-menu-item-image-<?php echo $item_id; ?>" class="widefat" name="menu-item-image[<?php echo $item_id; ?>]" value="<?php echo esc_attr($menu_item_image); ?>" />
        </label>
    </p>
    <?php
}
add_action('wp_nav_menu_item_custom_fields', 'add_custom_image_field_to_menu', 10, 4);

function save_menu_item_image($menu_id, $menu_item_db_id) {
    if (isset($_POST['menu-item-image'][$menu_item_db_id])) {
        $image_url = $_POST['menu-item-image'][$menu_item_db_id];
        update_post_meta($menu_item_db_id, '_menu_item_image', esc_url_raw($image_url));
    } else {
        delete_post_meta($menu_item_db_id, '_menu_item_image');
    }
}
add_action('wp_update_nav_menu_item', 'save_menu_item_image', 10, 2);

//Tắt update polylang
add_filter('site_transient_update_plugins', function ($transient) {
    if (isset($transient->response['polylang/polylang.php'])) {
        unset($transient->response['polylang/polylang.php']);
    }
    return $transient;
});

function admin_styles() {
    wp_enqueue_style('admin-customize-styles', get_template_directory_uri() . '/admin/css/main.css');
}
add_action('admin_enqueue_scripts', 'admin_styles');

/**
 * Dump data.
 */
if (!function_exists('dd')) {
    function dd()
    {
        $args = func_get_args();
        foreach ($args as $arg) {
            echo '<pre>';
            var_dump($arg);
            echo '</pre>';
            echo '<br>';
        }
        die();
    }
}
