<?php
/**
 * Home Page.
 *
 * @package          Trang Tien Plaza\Templates
 * @trangtienplaza-version 1.0.0
 */
get_header();

global $domain;
global $wp_query;
$term = get_queried_object();
$args = array(
    'post_type'      => 'brand',
    'posts_per_page' => -1,
    'lang'           => pll_current_language(),
    'tax_query'      => array(
        array(
            'taxonomy' => 'brand_category',
            'field'    => 'term_id',
            'terms'    => $term->term_id,
        ),
    ),
);
$query = new WP_Query($args);
?>
<div id="content" role="main" class="content-area">
    <section class="section py-3" id="section_477863630">
        <div class="bg section-bg fill bg-fill  bg-loaded">
        </div>
        <div class="section-content relative" <?php if(wp_is_mobile()){ echo 'style="margin-top: 2rem;"'; } ?>>            
            <div class="row" id="row-1727113603">
                <div id="col-115151647" class="col small-12 large-12">
                    <div class="col-inner">
                        <div id="text-3385127173" class="text py-2 box-head-brands">
                            <h1 class="title-category" style="margin-top:0;" data-aos="fade-up"><?php echo single_cat_title('', false); ?></h1>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col small-12 large-12 pb-0">
                            <div class="list-detail-brands">
                                <div class="row-brands">
                                <?php
                                    if($query->have_posts()){
                                        if(wp_is_mobile()){
                                            echo '<div class="row-item-floors">';
                                            while($query->have_posts()){
                                                $query->the_post();
                                                echo '<a title="'.esc_html(get_the_title()).'" href="'.esc_url(get_permalink()).'">'.esc_html(get_the_title()).'</a>';
                                            }
                                            echo '</div>';
                                        }else{
                                            $counter = 0;
                                            $opened_ul = false;
                                            while($query->have_posts()){
                                                if($counter % 5 == 0){
                                                    if ($opened_ul) {
                                                        echo '</div>';
                                                    }
                                                    echo '<div class="row-item-brands">';
                                                    $opened_ul = true;
                                                }
                                                $query->the_post();
                                                echo '<a title="'.esc_html(get_the_title()).'" href="'.esc_url(get_permalink()).'">'.esc_html(get_the_title()).'</a>';
                                                $counter++;
                                            }
                                            if ($opened_ul) {
                                                echo '</div>';
                                            }
                                        }
                                    }else{
                                        // echo '<p>No posts found in this category.</p>';
                                    }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style>
            #section_477863630 {
                padding-top: 30px;
                padding-bottom: 30px;
            }
            #section_477863630 .ux-shape-divider--top svg {
                height: 150px;
                --divider-top-width: 100%;
            }
            #section_477863630 .ux-shape-divider--bottom svg {
                height: 150px;
                --divider-width: 100%;
            }
        </style>
    </section>
</div>
<?php
get_footer(); // Include footer.php
?>