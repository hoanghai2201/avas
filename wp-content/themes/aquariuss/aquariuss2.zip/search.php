<?php
/**
 * The blog template file.
 *
 * @package          Trang Tien Plaza\Templates
 * @trangtienplaza-version 1.0.0
 */

get_header();
global $domain;
$query = get_search_query();

// Tùy chỉnh query chỉ tìm kiếm theo tiêu đề
$args = array(
    'post_type'      => array('luxury', 'brand', 'post'),
    'posts_per_page' => 12, 
    'paged'          => (get_query_var('paged')) ? get_query_var('paged') : 1,
    's'              => $query, 
);

// Áp dụng bộ lọc chỉ tìm kiếm trong tiêu đề
add_filter('posts_search', function ($search, $wp_query) use ($query) {
    global $wpdb;
    if (!empty($query)) {
        $search = $wpdb->prepare(" AND {$wpdb->posts}.post_title LIKE '%%%s%%' ", $query);
    }
    return $search;
}, 10, 2);

$search_query = new WP_Query($args);
?>

<div id="content" role="main" class="content-area">
    <section class="section" id="section_276009075">
        <div class="bg section-bg fill bg-fill bg-loaded">
        </div>
        <div class="section-content relative">
            <div class="row" id="row-1727113603">
                <div id="col-115151647" class="col small-12 large-12">
                    <div class="col-inner">
                        <div id="text-3385127173" class="text py-2">
                            <h3 class="pyt-5"><?php printf(pll__('Search Results for: %s', 'Translate'), esc_html($query)); ?></h3>
                            <style>
                                #text-3385127173 {
                                    text-align: center;
                                }
                            </style>
                        </div>
                        <div class="row list-luxury list-news-events-1 large-columns-3 medium-columns-1 small-columns-1">
                            <?php if ($search_query->have_posts()) : ?>
                                    <?php while ($search_query->have_posts()) : $search_query->the_post(); 
                                        $publish_date = get_the_date('d.m.y'); ?>
                                        <div class="col post-item" data-aos="fade-up" data-aos-delay="200">
                                            <div class="col-inner">
                                                <div class="box box-normal box-text-bottom box-blog-post has-hover">
                                                    <div class="box-image">
                                                        <div class="image-zoom image-cover" style="padding-top:100%;"> <img decoding="async" width="320" height="401" src="<?php echo esc_url(get_the_post_thumbnail_url($post, 'large')); ?>" class="attachment-medium size-medium wp-post-image" alt="<?php the_title(); ?>" /> </div>
                                                    </div>
                                                    <div class="box-text mpb-0">
                                                        <div class="box-text-inner blog-post-inner">
                                                            <span class="created_date"><?php echo esc_html($publish_date); ?></span>
                                                            <a style="display: block;" href="<?php the_permalink(); ?>" class="plain"><h5 class="post-title is-large"><?php the_title(); ?></h5></a>
                                                            <p class="text-left from_the_blog_excerpt"><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
                                                            <a href="<?php the_permalink(); ?>" class="mt-1 btn-readmore button-item hide-for-medium"><?php echo pll__('Continue reading'); ?></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endwhile; ?>

                                <div class="pagination">
                                    <?php
                                        $pagination_args = array(
                                            'total'   => $search_query->max_num_pages,
                                            'current' => max(1, get_query_var('paged')),
                                            'format' => '?paged=%#%', // Thay đổi URL phân trang
                                            'show_all' => false,
                                            'type' => 'plain',
                                            'prev_text' => '<span>'.pll__('Previous', 'Translate').'</span>',
                                            'next_text' => '<span>'.pll__('Next', 'Translate').'</span>',
                                        );
                                        $paginate_links = '<div class="pagination">'.paginate_links($pagination_args).'</div>';
                                    ?>
                                </div>
                            <?php else : ?>
                                <p><?php echo pll__('No results found. Please try again with different keywords.', 'Translate'); ?></p>
                            <?php endif; ?>

                            <?php wp_reset_postdata(); ?>
                        </div>
                        <div class="text-center py-4">
                            <?php echo $paginate_links; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style>
            #section_276009075 {
                padding-top: 0px;
                padding-bottom: 0px;
            }
            #section_276009075 .ux-shape-divider--top svg {
                height: 150px;
                --divider-top-width: 100%;
            }
            #section_276009075 .ux-shape-divider--bottom svg {
                height: 150px;
                --divider-width: 100%;
            }
        </style>
    </section>
</div>

<?php
// Xóa bộ lọc sau khi sử dụng
remove_filter('posts_search', 'search_in_titles');

get_footer(); 
?>